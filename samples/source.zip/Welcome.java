/*
 * Copyright 2015 Terence Doerksen
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *        http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

package ca.coffeeshopstudio.testapp;

import ca.coffeeshopstudio.icegl.controls.Button;
import ca.coffeeshopstudio.icegl.controls.CheckedButton;
import ca.coffeeshopstudio.icegl.controls.Label;
import ca.coffeeshopstudio.icegl.controls.Textbox;
import ca.coffeeshopstudio.icegl.gl.GLActivity;
import ca.coffeeshopstudio.icegl.gl.GLScreen;

/**
 * Drawing the welcome or main menu.
 */
public class Welcome extends GLScreen
{
    public Welcome(GLActivity activity)
    {
        super(activity);

        Label title = new Label(this);
        Button continueGame = new Button(this);
        CheckedButton newGame = new CheckedButton(this);
        Textbox editor = new Textbox(this);

        editor.setLeft(2);
        editor.setBottom(4);

        title.setBottom(10);
        title.setLeft(4);
        title.setFontSize(64);
        title.setText("Sample");

        continueGame.setBottom(3);
        continueGame.setLeft(1);
        continueGame.setText("Continue");
        continueGame.setWidth(6);

        newGame.setBottom(2);
        newGame.setLeft(1);
        newGame.setText("New Game");
        newGame.setWidth(6);
    }
}